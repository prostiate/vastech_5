$(document).ready(function() {
    $('#datepicker1').Zebra_DatePicker({
        icon_position: 'left'
    });
    $('#datepicker2').Zebra_DatePicker({
        icon_position: 'left'
    });
    $('#datepicker3').Zebra_DatePicker({
        icon_position: 'left'
    });
    $('#datepicker4').Zebra_DatePicker({
        icon_position: 'left'
    });
    $('#datepicker5').Zebra_DatePicker({
        icon_position: 'left'
    });
});