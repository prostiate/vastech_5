$(document).ready(function() {
    $(".datepicker").datepicker({
        // dateFormat: 'dd/mm/yyyy',
        dateFormat: 'd/m/Y',
        changeMonth: true,
        changeYear: true
    });
});
