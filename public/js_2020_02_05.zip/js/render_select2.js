$(document).ready(function() {
    $('.product_id').select2({
      width: '100%',
      placeholder: "Select a product",
      allowClear: true,
    });
});
